var chrome = require('ui/chrome');
var routes = require('ui/routes');
import html from './index.html';
import './root_controller';
import './less/app.less';
import './sections';

routes.enable();
routes.otherwise({
  redirectTo: '/rules'
});

chrome
  .setRootTemplate(html)
  .setRootController('elastalert', 'elastalertRootController');
